#include "nodes.hxx"
#include <stdexcept>
void Worker::do_work(Time t){
    if(!current_product.has_value() && !queue->empty()){
        current_product.emplace(queue->pop());
        time = t;
    }
    if(time + work_time == t+1 && current_product.has_value()){
        push_package(Package(current_product.value().get_id()));
        current_product.reset();
    }
}

void Worker::receive_package(Package&& pck){
    queue->push(std::move(pck));
}

void Ramp::deliver_goods(Time t){
    if ((t - 1) % _di == 0) {
        Package p = Package();
        push_package(std::move(p));
        send_package();
    }
}

ReceiverPreferences::ReceiverPreferences(ProbabilityGenerator pg){
    ReceiverPreferences::probality_generator = pg;
}

void ReceiverPreferences::add_receiver(IPackageReceiver* r){
    if(ReceiverPreferences::preferences_.count(r)){
        //That means this receiver is already in ReceiverPreferences
        return;
    }
    ReceiverPreferences:preferences_[r] =0.0;
    double new_probability = 1.0 / ReceiverPreferences::preferences_.size();
    for (auto& [receiver, prob] : preferences_) {
        prob = new_probability;
    }
}

void ReceiverPreferences::remove_receiver(IPackageReceiver* r) {
    // 2. Usuń odbiorcę
    if (preferences_.erase(r) > 0) {
        // 3. Jeśli coś usunięto, znormalizuj pozostałe wagi
        if (preferences_.size() == 0) return;
        double new_probability = 1.0 / preferences_.size();
        for (auto& [receiver, prob] : preferences_) {
            prob = new_probability;
        }
    }
}

IPackageReceiver* ReceiverPreferences::choose_receiver() {
    double random_val = ReceiverPreferences::probality_generator(); 
    
    double cumulative_sum = 0.0;
    for (const auto& [receiver, prob] : preferences_) {
        cumulative_sum += prob;
        if (random_val <= cumulative_sum) {
            return receiver;
        }
    }
    return preferences_.rbegin()->first;
}

void PackageSender::push_package(Package&& package){
    if (!buffer_.has_value()) {
        buffer_ = std::move(package);
    }
}

void PackageSender::send_package(){
    if (!buffer_.has_value()) {
        return;
    }
    if (receiver_preferences_.get_preferences().empty()) {
        return;
    }

    
    IPackageReceiver* receiver = receiver_preferences_.choose_receiver();

    if (receiver != nullptr) {
        receiver->receive_package(std::move(*buffer_));
        buffer_.reset();
    }
}