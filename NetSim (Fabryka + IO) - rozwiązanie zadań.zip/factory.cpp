#include "factory.hxx"
#include <sstream>
#include <iostream>
// --- Implementacja metod prywatnych i pomocniczych ---

// Szablonowa metoda usuwająca odbiorcę i czyszcząca referencje do niego
template <typename Node>
void Factory::remove_receiver(NodeCollection<Node>& collection, ElementID id) {
    // 1. Znajdź węzeł w kolekcji
    auto it = collection.find_by_id(id);
    if (it == collection.end()) {
        return; // Nie ma takiego elementu
    }

    // 2. Uzyskaj wskaźnik na interfejs IPackageReceiver tego węzła
    // Rzutujemy adres elementu iteratora na IPackageReceiver*
    IPackageReceiver* receiver_ptr = dynamic_cast<IPackageReceiver*>(&(*it));
    
    if (receiver_ptr) {
        // 3. Usuń wskaźnik z preferencji wszystkich Ramp
        for (auto& ramp : ramps_) {
            ramp.receiver_preferences_.remove_receiver(receiver_ptr);
        }

        // 4. Usuń wskaźnik z preferencji wszystkich Robotników
        for (auto& worker : workers_) {
            worker.receiver_preferences_.remove_receiver(receiver_ptr);
        }
    }

    // 5. Usuń fizycznie węzeł z kolekcji
    collection.remove_by_id(id);
}

// Helper DFS do sprawdzania spójności
// Zwraca true, jeśli z 'sender' da się dojść do jakiegokolwiek magazynu
bool has_reachable_storehouse(const PackageSender* sender, std::map<const PackageSender*, NodeColor>& node_colors) {
    // Jeśli węzeł już zweryfikowany pozytywnie wcześniej -> OK
    if (node_colors[sender] == NodeColor::VERIFIED) {
        return true;
    }
    
    if (node_colors[sender] == NodeColor::VISITED) {
        throw std::logic_error("Wykryto cykl w sieci bez wyjscia do magazynu.");
    }

    
    // Oznacz jako odwiedzony (w trakcie przetwarzania)
    node_colors[sender] = NodeColor::VISITED;

    // Pobierz preferencje (mapa <IPackageReceiver*, double>)
    // Uwaga: get_preferences() musi być const, jeśli nie jest w nodes.hpp, może być problem.
    // Zakładam, że w nodes.hpp jest metoda: const preferences_t& get_preferences(void) const;
    // Jeśli w nodes.hpp nie ma const przy tej metodzie, trzeba by użyć const_cast (brzydkie) 
    // lub zakładać, że nodes.hpp pozwala na dostęp. W przesłanym kodzie nodes.hpp get_preferences nie było const,
    // ale w kodzie fabryki operujemy na const PackageSender*.
    // Przyjmuję, że możemy pobrać preferencje.
    
    // Ponieważ sender jest const, musimy użyć const_cast jeśli metoda w nodes.hpp nie jest const-correct,
    // ale zakładamy, że logika na to pozwala. Dla bezpieczeństwa w tym przykładzie:
    auto& preferences = const_cast<PackageSender*>(sender)->receiver_preferences_.get_preferences();

    if (preferences.empty()) {
        throw std::logic_error("Nadawca nie posiada zadnego polaczenia wyjsciowego.");
    }

    bool has_other_receiver = false; // Czy posiada odbiorcę innego niż on sam

    for (const auto& pair : preferences) {
        IPackageReceiver* receiver = pair.first;
        
        // --- ZASTĘPSTWO ZA ENUMA: RTTI (dynamic_cast) ---
        
        // 1. Sprawdzamy czy to Magazyn
        if (receiver->get_reciver_type() == ReciverType::STOREHOUSE) {
            has_other_receiver = true; // Znaleziono magazyn -> ścieżka poprawna
        } 
        else{
            // 2. Skoro nie magazyn, sprawdzamy czy to Robotnik
            Worker* worker_ptr = dynamic_cast<Worker*>(receiver);
            if (worker_ptr != nullptr) {
                // Rzutowanie w górę na PackageSender, aby kontynuować DFS
                PackageSender* sendrecv_ptr = dynamic_cast<PackageSender*>(worker_ptr);
                
                // Sprawdzenie czy nie wskazuje na samego siebie
                if (sendrecv_ptr == sender) {
                    continue; 
                }
                
                has_other_receiver = true;
                    
                // Rekurencja TYLKO dla nieodwiedzonych
                if (node_colors[sendrecv_ptr] == NodeColor::UNVISITED) {
                    has_reachable_storehouse(sendrecv_ptr, node_colors);
                }
            }
        }
    }

    node_colors[sender] = NodeColor::VERIFIED;

    // KLUCZOWE: Rzuć wyjątek jeśli nie ma poprawnej ścieżki!
    if (!has_other_receiver) {
        throw std::logic_error("Brak osiagalnego magazynu (tylko self-loop lub brak polaczen).");
    }
    return true;
}

// --- Implementacja publicznego API Factory ---

void Factory::remove_worker(ElementID id) {
    remove_receiver(workers_, id);
}

void Factory::remove_storehouse(ElementID id) {
    remove_receiver(storehouses_, id);
}

void Factory::do_deliveries(Time t) {
    for (auto& ramp : ramps_) {
        ramp.deliver_goods(t);
    }
}

void Factory::do_package_passing(void) {
    for (auto& ramp : ramps_) {
        ramp.send_package();
    }
    for (auto& worker : workers_) {
        worker.send_package();
    }
}

void Factory::do_work(Time t) {
    for (auto& worker : workers_) {
        worker.do_work(t);
    }
}

bool Factory::is_consistent(void) {
    std::map<const PackageSender*, NodeColor> node_colors;

    
    for (const auto& ramp : ramps_) {
        node_colors[&ramp] = NodeColor::UNVISITED;
    }
    for (const auto& worker : workers_) {
        node_colors[&worker] = NodeColor::UNVISITED;
    }

    try {
        
        for (const auto& ramp : ramps_) {
            has_reachable_storehouse(&ramp, node_colors);
        }
    } catch (const std::logic_error&) {
        return false;
    }

    return true;
}

std::map<std::string,FactoryNode> enumToString = {
    {"LOADING_RAMP",FactoryNode::LOADING_RAMP  }, 
    {"WORKER",FactoryNode::WORKER } , 
    {"STOREHOUSE" , FactoryNode::STOREHOUSE} , 
    {"LINK", FactoryNode::LINK },
};

std::vector<std::string> character_split(const std::string& splittable_str, char delimiter) {
    std::stringstream parameter_stream(splittable_str);
    std::string part;
    std::vector<std::string> result;

    while(std::getline(parameter_stream, part, delimiter)) {
        result.push_back(part);
    }

    return result;
}

parsedLineData parse_line(std::string& line) {
    std::vector<std::string> tokens;
    std::string token;
    std::istringstream token_stream(line);
    char delimiter = ' ';
    while (std::getline(token_stream, token, delimiter))
        tokens.push_back(token);
    parsedLineData parsed_data;
    try {
        parsed_data.element_type = enumToString.at(tokens[0]);

        std::for_each(std::next(tokens.cbegin()), tokens.cend(), [&](const std::string& parameter_str) {
            auto key_value = character_split(parameter_str, '=');
            parsed_data.params[key_value[0]] = key_value[1];
        });
    } catch (std::out_of_range& ex) {
        throw std::exception();
    }

    return parsed_data;
}

std::vector<std::string> split(const std::string& txt, char delimiter){
    std::vector<std::string> tokens;
    std::string token;
    for(const auto& letter: txt){
        if(letter == delimiter){
            tokens.push_back(token);
            token = "";
        }else token += letter;
    }
    if(token.length() != 0) tokens.push_back(token);
    return tokens;
}

void link(Factory& f, const std::map<std::string, std::string>& params) {
    // 1. Poprawione nazwy zmiennych - src to nadawca, dest to odbiorca
    auto src_str = split(params.at("src"), '-');
    auto dest_str = split(params.at("dest"), '-');
    
    // 2. Walidacja rozmiaru
    if (src_str.size() < 2) {
        throw std::logic_error("Nieprawidłowy format linku");
    }
    
    // 3. Znajdź odbiorcę (receiver)
    IPackageReceiver* rec = nullptr;
    
    if (dest_str[0] == "store") {
        auto storehouse_it = f.find_storehouse_by_id(std::stoi(dest_str[1]));
        if (storehouse_it == f.storehouse_cend()) {
            throw std::logic_error("Nie znaleziono magazynu o ID: " + dest_str[1]);
        }
        rec = &const_cast<IPackageReceiver&>(static_cast<const IPackageReceiver&>(*storehouse_it));
    }
    else if (dest_str[0] == "worker") {
        auto worker_it = f.find_worker_by_id(std::stoi(dest_str[1]));
        if (worker_it == f.worker_cend()) {
            throw std::logic_error("Nie znaleziono robota o ID: " + dest_str[1]);
        }
        rec = &const_cast<IPackageReceiver&>(static_cast<const IPackageReceiver&>(*worker_it));
    }
    else {
        throw std::logic_error("Nieznany typ odbiorcy: " + dest_str[0]);
    }
    
    if (rec == nullptr) {
        throw std::logic_error("Brak odbiorcy");
    }
    
    // 4. Znajdź nadawcę (sender) i dodaj odbiorcę do jego preferencji
    if (src_str[0] == "ramp") {
        auto ramp_it = f.find_ramp_by_id(std::stoi(src_str[1]));
        if (ramp_it == f.ramp_cend()) {
            throw std::logic_error("Nie znaleziono rampy o ID: " + src_str[1]);
        }
        
        // Użyj metody, która zwraca NIECONST referencję do preferences
        // Zakładając, że masz metodę:
        // ReceiverPreferences& get_receiver_preferences() { return receiver_preferences_; }
        ramp_it->receiver_preferences_.add_receiver(rec);
    }
    else if (src_str[0] == "worker") {
        auto worker_it = f.find_worker_by_id(std::stoi(src_str[1]));
        if (worker_it == f.worker_cend()) {
            throw std::logic_error("Nie znaleziono robota o ID: " + src_str[1]);
        }
        worker_it->receiver_preferences_.add_receiver(rec);
    }
    else {
        throw std::logic_error("Nieznany typ nadawcy: " + src_str[0]);
    }
}

Factory load_factory_structure(std::istream& is){
    Factory factory;
    std::string line;
    while(std::getline(is, line)){
        if(line.empty() || line[0] == ';') continue;
        parsedLineData data = parse_line(line);
        switch(data.element_type){
            case FactoryNode::LOADING_RAMP:{
                ElementID id = std::stoi(data.params.at("id"));
                TimeOffset di = std::stoi(data.params.at("delivery-interval"));
                factory.add_ramp(Ramp(id, di));
                break;
            }
            case FactoryNode::WORKER:{
                ElementID id = std::stoi(data.params.at("id"));
                TimeOffset di = std::stoi(data.params.at("processing-time"));
                PackageQueueType type_t = (data.params.at("queue-type")=="FIFO")? PackageQueueType::FIFO : PackageQueueType::LIFO;
                factory.add_worker(Worker(id, di, std::make_unique<PackageQueue>(type_t)));
                break;
            }
            case FactoryNode::STOREHOUSE:{
                ElementID id = std::stoi(data.params.at("id"));
                factory.add_storehouse(Storehouse(id));
                break;
            }
            case FactoryNode::LINK:{
                link(factory, data.params);
                break;
            }
        }
    }

    return factory;
}

std::string queue_type_str(PackageQueueType package_queue_type) {
    switch(package_queue_type) {
        case PackageQueueType::FIFO:
            return "FIFO";
        case PackageQueueType::LIFO:
            return "LIFO";
    }
    return {};
}

void link_stream_fill(std::stringstream& link_stream, const PackageSender& package_sender, ElementID package_sender_id, std::string&& package_sender_name) {
    auto prefs = package_sender.receiver_preferences_.get_preferences();

    std::for_each(prefs.cbegin(), prefs.cend(), [&](const std::pair<IPackageReceiver*, double>& key_value) {
        link_stream << "LINK src=" << package_sender_name << "-" << package_sender_id << " ";
        const IPackageReceiver* package_receiver = key_value.first;
        ReciverType receiver_type = package_receiver->get_reciver_type();

        std::string receiver_type_str = receiver_type == ReciverType::WORKER ? "worker" : "store";
        link_stream << "dest=" << receiver_type_str << "-" << package_receiver->get_id() << '\n';
        std::cout << link_stream.str();
    });
}

void save_factory_structure(const Factory& factory, std::ostream& os){
    std::stringstream link_stream;
    std::for_each(factory.ramp_cbegin(), factory.ramp_cend(), [&](const Ramp& ramp) {
        ElementID ramp_id = ramp.get_id();
        os << "LOADING_RAMP id=" << ramp_id << ' ' << "delivery-interval=" << ramp.get_delivery_interval() << '\n';
        link_stream_fill(link_stream, ramp, ramp_id, "ramp");
    });
    std::for_each(factory.worker_cbegin(), factory.worker_cend(), [&](const Worker& worker) {
        PackageQueueType queue_type = worker.get_queue()->get_queue_type();
        ElementID worker_id = worker.get_id();
        os << "WORKER id=" << worker_id << ' ' << "processing-time=" << worker.get_processing_duration() << ' ' << "queue-type=" << queue_type_str(queue_type) << '\n';
        link_stream_fill(link_stream, worker, worker_id, "worker");
    });
    std::for_each(factory.storehouse_cbegin(), factory.storehouse_cend(), [&](const Storehouse& storehouse) {
        os << "STOREHOUSE id=" << storehouse.get_id() << '\n';
    });
    os << link_stream.str();
    os.flush();

}